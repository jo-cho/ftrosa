__version__ = '0.1.0'

from .aggregation import get_all_musical_features

from . import aggregation, features, feature_stats, visualization
